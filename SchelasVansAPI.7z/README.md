# Schelas Vans

## O Projeto
```
O SchelasVans é um gerenciador de frotas de vans.

O Projeto está sendo desenvolvido para o TCC pela
Universidade Tuiuti do Paraná
```

### Repositório
```
Este repositório irá servir como o Backend da aplicação principal.
```


### Grupo
```
Wiltencir D Garcia - Fullstack
Bruno Teixeira dos Santos - Frontend
```
